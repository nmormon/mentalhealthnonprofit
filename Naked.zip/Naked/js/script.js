

$.getJSON("https://www.eventbrite.com/oauth/authorize?response_type=token&client_id=UMT6PGB32Q36Z4VWBK&redirect_uri=www.nakedcampaign.org",
function(data) {
  console.log(data);



});
